# Acerca de
Proyecto de prueba con el objetivo de aprender cómo funciona Git.

## ¿Qués es Git?
Git es un software de gestión de versiones muy utilizado en el mundo del desarrollo de aplicaciones.